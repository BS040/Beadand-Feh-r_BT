package model;

import java.sql.Connection;
import java.util.ArrayList;

public class DatabaseManager {
    private String fileName;

    public DatabaseManager(String fileName) {
        this.fileName = fileName;
    }

    private String[] getSql() {
        return new String[0];
    }

    
    public boolean setCitiesData(Connection conn, ArrayList<String> cities) {
        
        return false;
    }

    
    public boolean setWorkersData(Connection conn, ArrayList<String> workers) {
        
        return false;
    }
}
