package model;

import java.sql.Date;

public class Worker {
    private int id;
    private String name;
    private String address;
    private int salary;
    private int bonus;
    private Date birthDate;
    private Date hireDate;
    private int cityId;
    private int age;
    
    public Worker(int id, String name, String address, int salary, int age, int bonus, Date birthDate, Date hireDate, int cityId) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.address = address;
        this.salary = salary;
        this.bonus = bonus;
        this.birthDate = birthDate;
        this.hireDate = hireDate;
        this.cityId = cityId;
    }
    
    public Worker(String name, int age) {
        this.name = name;
        this.age = age;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public int getBonus() {
        return bonus;
    }

    public void setBonus(int bonus) {
        this.bonus = bonus;
    }

    public Date getBirthdate() {
        return birthDate;
    }

    public void setBirthdate(Date birthDate) {
        this.birthDate = birthDate;
    }

    public Date getHiredate() {
        return hireDate;
    }

    public void setHiredate(Date hiredate) {
        this.hireDate = hiredate;
    }

    public int getCity_id() {
        return cityId;
    }

    public void setCity_id(int city_id) {
        this.cityId = city_id;
    }
}

