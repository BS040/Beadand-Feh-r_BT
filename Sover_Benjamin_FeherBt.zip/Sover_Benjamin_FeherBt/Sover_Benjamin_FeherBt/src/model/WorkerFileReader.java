package model;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class WorkerFileReader {
    public Worker readWorkerFromFile(String fileName) {
        try {
            File file = new File(fileName);
            Scanner scanner = new Scanner(file);

            String name = scanner.nextLine();
            int age = scanner.nextInt();

            Worker worker = new Worker(name, age);

            scanner.close();

            return worker;
        } catch (FileNotFoundException e) {
            System.out.println("A fájl nem található: " + e.getMessage());
            return null;
        }
    }
}


