package control;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class FajlController {

    // public List<String> readFile(String fileName)
        public static void main(String[] args) {
        try {
            FileReader reader = new FileReader("feherBt.txt"); 
            int data = reader.read();
            while (data != -1) {
                System.out.print((char) data);
                data = reader.read();
                
            }
            
            reader.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        // return null;
    }
}