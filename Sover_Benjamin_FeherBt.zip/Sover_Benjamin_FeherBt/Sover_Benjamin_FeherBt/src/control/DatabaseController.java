package control;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseController {
    private Connection connection;

    public DatabaseController() {
        connect();
    }

    private void connect() {
        try {
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sover_benjamin_feherbt", "", "");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}