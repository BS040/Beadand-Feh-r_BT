package control;

import model.Worker;
import model.WorkerFileReader;
public class MainController {
    public static void main(String[] args) {
        WorkerFileReader reader = new WorkerFileReader();
        Worker worker = reader.readWorkerFromFile("feherBt.txt");

        DatabaseController databaseController = new DatabaseController();
        // databaseController.saveWorkerToDatabase(worker);
        // databaseController.WorkersFromDatabase();
    
    }
}



