import control.MainController;
public class fajl {
    public static void main(String[] args){
        new MainController();
    }
}
