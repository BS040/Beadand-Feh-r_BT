CREATE TABLE workers (
    id INT PRIMARY KEY,
    name VARCHAR(20),
    address VARCHAR(50),
    salary INT,
    bonus INT,
    borndate DATE,
    hiredate DATE,
    city_id INT,
    FOREIGN KEY(city_id) REFERENCES cities(id)
);
