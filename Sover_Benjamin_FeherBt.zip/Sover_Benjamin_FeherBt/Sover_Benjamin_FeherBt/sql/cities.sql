CREATE TABLE cities (
    id INT PRIMARY KEY,
    city VARCHAR(20)
);